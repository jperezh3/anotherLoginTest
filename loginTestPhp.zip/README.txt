== Author ==

Jaime Alejandro Perez Heredia

Country: Colombia
email: jperezh3@gmail.com

== Description ==

This is a simple login application made with PHP, MySQL, HTML and JavaScript for the test in Fynske Medier.

It consist of a index page where the user can create or log in to the application, it validates if the user is created in the database.

It uses jQuery and twitter bootstrap for better graphic design and more easy DOM handle.

Even if the part for register a new user was not required, it was decided to made in case the database have no records.

== Installation ==

The installation is quite simple, just unpack all the files in a folder inside www. 

For the database it needs a created and running database, the database name and the table structure is in the file db.sql.

This application was made and tested with WAMP server 2.4 that has

PHP 5.4.12
MYSQL 5.6.12
APACHE 2.4.4

